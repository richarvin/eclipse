DashLookup
==========

Eclipse plugin to enable lookups in Dash.app for selected text

# Instructions

* Clone or download this repo
* Import the project into Eclipse workspace (File > Import > General > Existing Projects into Workspace)
* Export it as deployable plugin (File > Export > Plug-in Development > Deployable Plug-ins and Fragments) and choose install into host
  * Note: If you don't see a "Plug-in Development" option in File > Export, you need to install the "Eclipse Plug-in Development Environment" which can be done by going to Help > Install New Software > General Purpose Tools > Eclipse Plug-in Development Environment
* Restart Eclipse
* Go to Preferences > General > Keys and bind the "Lookup in Dash" command to whatever you desire
